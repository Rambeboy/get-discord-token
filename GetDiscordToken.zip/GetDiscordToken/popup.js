document.getElementById("getToken").addEventListener("click", () => {
    document.getElementById("status").textContent = "Retrieving token...";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
            document.getElementById("status").textContent = "Invalid tab!";
            return;
        }

        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: () => JSON.parse(localStorage.getItem("token"))
        }, (results) => {
            if (chrome.runtime.lastError || !results || !results[0].result) {
                document.getElementById("status").textContent = "Failed to retrieve token!";
            } else {
                let token = results[0].result;
                document.getElementById("tokenDisplay").value = token;
                document.getElementById("status").textContent = "Token successfully retrieved!";
            }
        });
    });
});

document.getElementById("copyToken").addEventListener("click", () => {
    let token = document.getElementById("tokenDisplay").value;
    if (token) {
        navigator.clipboard.writeText(token).then(() => {
            document.getElementById("status").textContent = "Token copied to clipboard!";
        }).catch(() => {
            document.getElementById("status").textContent = "Failed to copy token!";
        });
    } else {
        document.getElementById("status").textContent = "No token to copy!";
    }
});

document.getElementById("loginToken").addEventListener("click", () => {
    let token = document.getElementById("inputToken").value;
    if (!token) {
        document.getElementById("loginStatus").textContent = "Please enter a token first!";
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        let currentTab = tabs[0];

        if (!currentTab.url.includes("https://discord.com/login")) {
            document.getElementById("loginStatus").innerHTML = "You must be on <b>https://discord.com/login</b>!";
            return;
        }

        chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            func: loginWithToken,
            args: [token]
        }, (results) => {
            if (chrome.runtime.lastError || !results) {
                document.getElementById("loginStatus").textContent = "Failed to log in with token!";
            } else {
                document.getElementById("loginStatus").textContent = "Login successful! Please open Discord.";
            }
        });
    });
});

function loginWithToken(token) {
    setTimeout(() => {
        document.body.appendChild(document.createElement `iframe`).contentWindow.localStorage.token = `"${token}"`;
        location.reload();
    }, 1000);
}