chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getToken") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: grabToken
            }, (result) => {
                if (chrome.runtime.lastError || !result[0]?.result) {
                    sendResponse({ success: false, error: "Failed to retrieve token!" });
                } else {
                    sendResponse({ success: true, token: result[0].result });
                }
            });
        });
        return true;
    }
});

function grabToken() {
    return localStorage.getItem("token")?.replace(/"/g, "");
}