(function() {
    try {
        let token = JSON.parse(localStorage.getItem("token"));  
        
        if (token) {
            console.log("Token found:", token);
            chrome.runtime.sendMessage({ action: "copyToken", token: token }, (response) => {
                if (response && response.success) {
                    console.log("Token successfully copied to clipboard!");
                } else {
                    console.log("Failed to copy token to clipboard!");
                }
            });
        } else {
            console.log("Token not found in localStorage!");
        }
    } catch (e) {
        console.log("Error retrieving token:", e);
    }
})();